package inventory.app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class EditProductActivity extends AppCompatActivity {
    private EditText editProductName, editProductQuantity, editProductDescription;
    private ImageView productImage;
    private Button saveProductButton, backButton;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_product);

        // Initialize DBHelper
        dbHelper = new DBHelper(this);

        // Initialize views
        editProductName = findViewById(R.id.editProductName);
        editProductQuantity = findViewById(R.id.editProductQuantity);
        editProductDescription = findViewById(R.id.editProductDescription);
        productImage = findViewById(R.id.productImage);
        saveProductButton = findViewById(R.id.saveProductButton);
        backButton = findViewById(R.id.backButton);

        // Retrieve and set item details if any
        Intent intent = getIntent();
        int itemId = intent.getIntExtra("itemId", -1);
        if (itemId != -1) {
            // It's an update
            editProductName.setText(intent.getStringExtra("itemName"));
            editProductQuantity.setText(String.valueOf(intent.getIntExtra("itemQuantity", 0)));
            editProductDescription.setText(intent.getStringExtra("itemDescription"));
        }

        // Setup back button to finish the activity
        backButton.setOnClickListener(v -> finish());

        // Setup save button listener
        saveProductButton.setOnClickListener(v -> saveProductChanges(itemId));
    }

    private void saveProductChanges(int itemId) {
        String name = editProductName.getText().toString().trim();
        int quantity = Integer.parseInt(editProductQuantity.getText().toString().trim());
        String description = editProductDescription.getText().toString().trim();

        boolean success;
        if (itemId == -1) {
            // It's a new item
            success = dbHelper.addItem(name, quantity, description);
        } else {
            // It's an update
            success = dbHelper.updateItem(itemId, name, quantity, description);
        }

        if (success) {
            Toast.makeText(this, "Item saved successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Failed to save item", Toast.LENGTH_SHORT).show();
        }
        finish(); // Close activity after saving
    }
}


