package inventory.app;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class WelcomeActivity extends AppCompatActivity {

    private CheckBox smsPermissionCheckbox;
    private CheckBox noThanksCheckbox;
    private Button continueButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        smsPermissionCheckbox = findViewById(R.id.smsPermissionCheckbox);
        noThanksCheckbox = findViewById(R.id.noThanksCheckbox);
        continueButton = findViewById(R.id.continueButton);

        smsPermissionCheckbox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                noThanksCheckbox.setChecked(false);
            }
        });

        noThanksCheckbox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                smsPermissionCheckbox.setChecked(false);
            }
        });

        continueButton.setOnClickListener(v -> {
            if (smsPermissionCheckbox.isChecked() && !noThanksCheckbox.isChecked()) {
                if (ContextCompat.checkSelfPermission(WelcomeActivity.this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(WelcomeActivity.this, new String[]{Manifest.permission.SEND_SMS}, 101);
                } else {
                    proceedWithSMSPermissionGranted();
                }
            } else {
                proceedToNextActivity();
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 101 && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            proceedWithSMSPermissionGranted();
        } else {
            Toast.makeText(this, "SMS permission denied. SMS features will be disabled.", Toast.LENGTH_LONG).show();
            proceedToNextActivity();
        }
    }

    private void proceedWithSMSPermissionGranted() {
        // Save permission granted state using SharedPreferences
        SharedPreferences prefs = getSharedPreferences("AppPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean("smsPermissionGranted", true);
        editor.apply();


        Toast.makeText(this, "SMS permission granted. SMS features will be enabled.", Toast.LENGTH_LONG).show();

        proceedToNextActivity();
    }

    private void proceedToNextActivity() {
        Intent intent = new Intent(this, InventoryGridActivity.class);
        startActivity(intent);
        finish();  // Close WelcomeActivity after navigating away
    }
}





