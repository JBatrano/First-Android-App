package inventory.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private Button createAccountButton;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize the database helper
        dbHelper = new DBHelper(this);

        // Link UI elements from layout to Java code
        usernameEditText = findViewById(R.id.username);
        passwordEditText = findViewById(R.id.password);
        loginButton = findViewById(R.id.loginButton);
        createAccountButton = findViewById(R.id.createAccountButton);

        // Setup login button click listener
        loginButton.setOnClickListener(v -> {
            String username = usernameEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();
            if (validateCredentials(username, password)) {
                navigateToWelcomeActivity();
            } else {
                Toast.makeText(MainActivity.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
            }
        });

        // Setup create account button click listener
        createAccountButton.setOnClickListener(v -> navigateToRegisterActivity());
    }

    /**
     * Validates the username and password with the database.
     * @param username User's username
     * @param password User's password
     * @return true if credentials are valid, false otherwise
     */
    private boolean validateCredentials(String username, String password) {
        return dbHelper.checkUser(username, password);
    }

    /**
     * Navigates to the WelcomeActivity upon successful login.
     */
    private void navigateToWelcomeActivity() {
        Intent intent = new Intent(MainActivity.this, WelcomeActivity.class);
        startActivity(intent);
        finish();  // Close MainActivity after navigating away
    }

    /**
     * Navigates to the RegisterActivity for new account creation.
     */
    private void navigateToRegisterActivity() {
        Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
        startActivity(intent);
    }
}


