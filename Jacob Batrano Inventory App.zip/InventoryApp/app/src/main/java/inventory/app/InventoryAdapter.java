package inventory.app;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.InventoryViewHolder> {

    private final List<InventoryItem> itemList;
    private final InventoryGridActivity activity; // Changed from Context to specific activity reference

    public InventoryAdapter(List<InventoryItem> itemList, InventoryGridActivity activity) {
        this.itemList = itemList;
        this.activity = activity;
    }

    @NonNull
    @Override
    public InventoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_inventory, parent, false);
        return new InventoryViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull InventoryViewHolder holder, int position) {
        InventoryItem item = itemList.get(position);
        holder.itemName.setText(item.getName());
        holder.itemQuantity.setText(String.valueOf(item.getQuantity()));

        // Set up delete button
        holder.deleteButton.setOnClickListener(v -> {
            activity.deleteItem(item.getId()); // Call delete method in the activity
            itemList.remove(position); // Remove the item from the list
            notifyItemRemoved(position); // Notify the adapter of item removal
            notifyItemRangeChanged(position, itemList.size()); // Notify the change in the range
        });

        // Set up edit button
        holder.editButton.setOnClickListener(v -> {
            Intent intent = new Intent(activity, EditProductActivity.class);
            intent.putExtra("itemId", item.getId());
            intent.putExtra("itemName", item.getName());
            intent.putExtra("itemQuantity", item.getQuantity());
            intent.putExtra("itemDescription", item.getDescription());
            activity.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    static class InventoryViewHolder extends RecyclerView.ViewHolder {
        TextView itemName;
        TextView itemQuantity;
        Button editButton;
        Button deleteButton; // Reference to the delete button

        InventoryViewHolder(View view) {
            super(view);
            itemName = view.findViewById(R.id.itemName);
            itemQuantity = view.findViewById(R.id.itemQuantity);
            editButton = view.findViewById(R.id.editButton);
            deleteButton = view.findViewById(R.id.deleteButton); // Initialize delete button
        }
    }
}
