package inventory.app;

public class InventoryItem {
    private int id; // To uniquely identify each item
    private String name;
    private int quantity;
    private String description; // Added to include a description for each item

    // Constructor for creating a new item when no ID is yet assigned
    public InventoryItem(String name, int quantity, String description) {
        this(-1, name, quantity, description); // Call the main constructor with -1 as the default ID
    }

    // Main constructor used for fully specified items, typically when retrieving from database
    public InventoryItem(int id, String name, int quantity, String description) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.description = description;
    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}

