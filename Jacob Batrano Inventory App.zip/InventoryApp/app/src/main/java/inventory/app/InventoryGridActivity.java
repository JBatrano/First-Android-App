package inventory.app;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;
import java.util.List;

public class InventoryGridActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private InventoryAdapter adapter;
    private List<InventoryItem> itemList = new ArrayList<>();
    private DrawerLayout drawerLayout;
    private ActionBarDrawerToggle toggle;
    private NavigationView navigationView;
    private Button addNewItemButton; // Button to add new items
    private DBHelper dbHelper; // Database helper

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_grid);

        // Initialize DBHelper
        dbHelper = new DBHelper(this);

        // Set up the RecyclerView
        recyclerView = findViewById(R.id.recyclerViewInventory);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new InventoryAdapter(itemList, this);
        recyclerView.setAdapter(adapter);

        // Set up the Drawer
        drawerLayout = findViewById(R.id.drawer_layout);
        toggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.open, R.string.close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        // Enable the home button to control the drawer
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(item -> {
            switch (item.getItemId()) {
                // Add cases for navigation items if needed
            }
            drawerLayout.closeDrawers();  // Close the drawer when an item is tapped
            return true;
        });

        // Button for adding new items
        addNewItemButton = findViewById(R.id.addItemButton);
        addNewItemButton.setOnClickListener(v -> navigateToAddItem());

        loadInventory(); // Load the inventory initially
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Pass the event to ActionBarDrawerToggle
        if (toggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadInventory(); // Refresh the inventory list every time activity resumes
    }

    private void navigateToAddItem() {
        Intent intent = new Intent(this, EditProductActivity.class);
        startActivity(intent);
    }

    private void loadInventory() {
        itemList.clear();  // Clear the existing data
        Cursor cursor = dbHelper.getAllItems();  // Fetch new inventory items from the database

        int itemCount = 0;  // Initialize the item count variable

        if (cursor != null && cursor.moveToFirst()) {
            do {
                int idIndex = cursor.getColumnIndex(DBHelper.COLUMN_ITEM_ID);
                int nameIndex = cursor.getColumnIndex(DBHelper.COLUMN_ITEM_NAME);
                int quantityIndex = cursor.getColumnIndex(DBHelper.COLUMN_ITEM_QUANTITY);
                int descriptionIndex = cursor.getColumnIndex(DBHelper.COLUMN_ITEM_DESCRIPTION);

                if (idIndex != -1 && nameIndex != -1 && quantityIndex != -1 && descriptionIndex != -1) {
                    int id = cursor.getInt(idIndex);
                    String name = cursor.getString(nameIndex);
                    int quantity = cursor.getInt(quantityIndex);
                    String description = cursor.getString(descriptionIndex);

                    itemList.add(new InventoryItem(id, name, quantity, description));
                    itemCount++;  // Increment the count of items loaded
                }
            } while (cursor.moveToNext());
        }

        if (cursor != null) {
            cursor.close();  // Close the cursor to free resources
        }

        adapter.notifyDataSetChanged();  // Notify the adapter about the data change

        // Debugging: Output the number of items loaded
        System.out.println("Loaded " + itemCount + " items from the database.");
    }


    public void deleteItem(int itemId) {
        if (dbHelper.deleteItem(itemId)) {
            // If the item was successfully deleted, reload the inventory to update the UI
            loadInventory();
            Toast.makeText(this, "Item deleted successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Failed to delete the item", Toast.LENGTH_SHORT).show();
        }
    }

    public void navigateToEditItem(int itemId) {
        Intent intent = new Intent(this, EditProductActivity.class);
        intent.putExtra("itemId", itemId);  // Pass the ID to the EditProductActivity
        startActivity(intent);
    }

}




